<?php
// -----------------------------------------------
// Din 17track API-nyckel – ändra värdet nedan
// Denna fil ska ALDRIG vara publikt tillgänglig
// -----------------------------------------------
define('API_KEY_17TRACK', 'DIN_NYCKEL_HÄR');
